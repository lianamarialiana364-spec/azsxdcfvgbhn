import json
import os
import sqlite3
import time
from unittest.mock import patch
from test_support import AccountTestCase, app
from auth import send_code
from werkzeug.security import check_password_hash

class AuthenticationTests(AccountTestCase):
    def register_verified(self,email="aluna@example.test"):
        with patch("auth.send_code") as send:
            response=self.form("/cadastro",{"name":"Letícia","email":email,"password":"senha-inicial-123","confirm_password":"senha-inicial-123"})
            self.assertEqual(response.status_code,302)
            code=send.call_args.args[1]
        response=self.form("/confirmar-email",{"code":code})
        self.assertIn("confirmed=1",response.location)
        return code

    def test_register_verify_login_logout(self):
        with patch("auth.send_code") as send:
            response=self.form("/cadastro",{"name":"Letícia","email":"Aluna@example.test","password":"senha-inicial-123","confirm_password":"senha-inicial-123"})
            self.assertEqual(response.status_code,302)
            self.assertEqual(send.call_args.args[0],"aluna@example.test")
            code=send.call_args.args[1]
        response=self.form("/login",{"email":"aluna@example.test","password":"senha-inicial-123"})
        self.assertNotEqual(response.status_code,302)
        self.assertIn(b"confirmado",response.data)
        self.form("/confirmar-email",{"code":code})
        with sqlite3.connect(app.config["AUTH_DATABASE"]) as conn:
            hashed,verified=conn.execute("SELECT password_hash,verified FROM accounts").fetchone()
        self.assertNotEqual(hashed,"senha-inicial-123")
        self.assertTrue(check_password_hash(hashed,"senha-inicial-123"))
        self.assertEqual(verified,1)
        self.assertEqual(self.form("/login",{"email":"aluna@example.test","password":"senha-inicial-123"}).status_code,302)
        self.assertEqual(self.client.get("/").status_code,200)
        self.form("/sair")
        self.assertEqual(self.client.get("/").location,"/login")

    def test_auth_and_csrf_required(self):
        self.assertEqual(self.client.get("/api/catalogo").status_code,401)
        self.assertEqual(self.client.post("/login",data={}).status_code,400)
        self.authenticate()
        self.client.environ_base.pop("HTTP_X_CSRF_TOKEN")
        self.assertEqual(self.client.post("/api/trilha",json={"objetivos":["python"]}).status_code,400)

    def test_reset_invalidates_sessions_and_code(self):
        self.register_verified()
        self.form("/login",{"email":"aluna@example.test","password":"senha-inicial-123"})
        old=app.test_client()
        old.set_cookie("session",self.client.get_cookie("session").value)
        with patch("auth.send_code") as send:
            self.form("/esqueci-senha",{"email":"aluna@example.test"})
            code=send.call_args.args[1]
        response=self.form("/redefinir-senha",{"code":code,"password":"nova-senha-456","confirm_password":"nova-senha-456"})
        self.assertIn("reset=1",response.location)
        self.assertEqual(old.get("/api/catalogo").status_code,401)
        response=self.form("/redefinir-senha",{"code":code,"password":"outra-senha-789","confirm_password":"outra-senha-789"})
        self.assertIn("Código inválido".encode(),response.data)
        self.assertEqual(self.form("/login",{"email":"aluna@example.test","password":"nova-senha-456"}).status_code,302)

    def test_expiry_and_attempt_limit(self):
        with patch("auth.send_code") as send:
            self.form("/cadastro",{"name":"Letícia","email":"aluna@example.test","password":"senha-inicial-123","confirm_password":"senha-inicial-123"})
            code=send.call_args.args[1]
        wrong="000000" if code!="000000" else "111111"
        for _ in range(5):
            self.form("/confirmar-email",{"code":wrong})
        self.assertIn("Código inválido".encode(),self.form("/confirmar-email",{"code":code}).data)
        with sqlite3.connect(app.config["AUTH_DATABASE"]) as conn:
            conn.execute("UPDATE challenges SET attempts=0,expires=?",(time.time()-1,))
        self.assertIn("Código inválido".encode(),self.form("/confirmar-email",{"code":code}).data)

    def test_missing_smtp_is_explicit(self):
        with patch.dict(os.environ,{"SMTP_HOST":""}):
            response=self.form("/cadastro",{"name":"Letícia","email":"aluna@example.test","password":"senha-inicial-123","confirm_password":"senha-inicial-123"})
        self.assertIn("não foi configurado".encode(),response.data)

    def test_mail_failure_does_not_verify(self):
        with patch("auth.send_code",side_effect=RuntimeError("private")):
            response=self.form("/cadastro",{"name":"Letícia","email":"aluna@example.test","password":"senha-inicial-123","confirm_password":"senha-inicial-123"})
        self.assertIn("Não foi possível".encode(),response.data)
        self.assertNotIn(b"private",response.data)
        with sqlite3.connect(app.config["AUTH_DATABASE"]) as conn:
            self.assertEqual(conn.execute("SELECT verified FROM accounts").fetchone()[0],0)
            self.assertEqual(conn.execute("SELECT count(*) FROM challenges").fetchone()[0],0)

    def test_unknown_email_generic_response(self):
        with patch("auth.send_code") as send:
            response=self.form("/esqueci-senha",{"email":"unknown@example.test"})
        self.assertEqual(response.location,"/redefinir-senha")
        send.assert_not_called()
        self.assertIn("Se o e-mail".encode(),self.client.get(response.location).data)

    def test_trail_is_saved_per_account(self):
        uid=self.authenticate()
        self.client.post("/api/trilha",json={"objetivos":["java"]})
        with sqlite3.connect(app.config["AUTH_DATABASE"]) as conn:
            stored=json.loads(conn.execute("SELECT trail FROM accounts WHERE id=?",(uid,)).fetchone()[0])
        self.assertEqual(stored["course_ids"],["java"])
        self.assertIn(b'account_',self.client.get("/").data)
        self.form("/sair")
        self.client.environ_base.pop("HTTP_X_CSRF_TOKEN")
        with self.client.session_transaction() as session:
            self.assertNotIn("uid",session)

    def test_smtp_uses_tls_and_correct_recipient(self):
        with patch("auth.smtplib.SMTP") as smtp:
            send_code("aluna@example.test","123456","verify")
        server=smtp.return_value.__enter__.return_value
        server.starttls.assert_called_once()
        message=server.send_message.call_args.args[0]
        self.assertEqual(message["To"],"aluna@example.test")
        self.assertIn("123456",message.get_content())
