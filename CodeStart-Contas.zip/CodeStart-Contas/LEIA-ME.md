# CodeStart — contas verificadas e trilhas por linguagem

## O que mudou
- Login, cadastro, confirmação por código de e-mail, recuperação de senha e sair.
- Senhas com hash; códigos de uso único, validade de 15 minutos e até 5 tentativas.
- Nova senha invalida sessões anteriores.
- Trilha salva na conta: Python → Python; Java → Java; JavaScript → JavaScript.
- Seleção de objetivo corrigida; outros objetivos do catálogo continuam disponíveis.
- Progresso, notas e histórico continuam no navegador, agora separados por conta.
- Catálogo, aulas, editor, jogos, projetos, dashboard, acessibilidade e tutor local preservados.
- Escapes de Markdown que corrompiam o Python e o CSS foram removidos.

## 1. Extraia e abra a pasta
Envie CodeStart-Contas.zip à pasta principal do Codespaces.
No terminal dessa pasta:
    unzip "CodeStart-Contas.zip"
    cd CodeStart-Contas
Se o download ganhou "(1)" no nome, use o nome exato entre aspas.

## 2. Configure o envio de e-mail (necessário para cadastrar)
O código está integrado a SMTP real. Você precisa fornecer uma conta remetente.
Nenhum código é exibido no site ou nos logs para substituir o e-mail.

Opção A — arquivo local:
- Crie um arquivo chamado .env na mesma pasta de app.py.
- Copie nele o conteúdo de .env.example.
- Preencha SMTP_HOST, SMTP_PORT, SMTP_SECURITY, SMTP_USER, SMTP_PASSWORD e MAIL_FROM.
- Não publique .env no GitHub; já está no .gitignore.

Opção B — Codespaces secrets:
- Acesse https://github.com/settings/codespaces
- Adicione as mesmas variáveis e autorize o repositório correto.
- Pare o Codespaces (Stop codespace), abra novamente e inicie o site.
- Valores nos secrets têm prioridade sobre .env.

Exemplo para Gmail pessoal, se sua conta permitir senhas de app:
    SMTP_HOST=smtp.gmail.com
    SMTP_PORT=587
    SMTP_SECURITY=starttls
    SMTP_USER=seu-email@gmail.com
    SMTP_PASSWORD=senha-de-app-sem-espacos
    MAIL_FROM=seu-email@gmail.com
    PORT=5001

Use uma senha de app, NÃO a senha normal do Gmail.
A conta precisa ter verificação em duas etapas; contas escolares e contas com
certas políticas podem não oferecer senhas de app:
https://support.google.com/accounts/answer/185833?hl=pt-BR

Também funciona com outro provedor SMTP usando os parâmetros fornecidos por ele.
Para porta 465 com SSL, use SMTP_SECURITY=ssl.
Seu provedor pode limitar envios ou exigir validação do remetente.
Se a hospedagem bloquear conexões SMTP, será necessário usar uma hospedagem que
permita SMTP ou adaptar o envio para a API de um provedor de e-mail.

## 3. Execute o site
    python -m pip install -r requirements.txt
    python app.py

Abra a porta mostrada no terminal (5001 se você definiu PORT=5001).
No primeiro acesso aparecerá o login. Clique em Criar conta, preencha o formulário,
consulte seu e-mail e digite o código na MESMA aba em que começou o cadastro.
Confira também o spam. Depois faça login.

## 4. Tutor local (Ollama)
O tutor foi mantido. Se Ollama já estiver instalado:
- Em outro terminal, execute: ollama serve
- Se o modelo não estiver instalado: ollama pull qwen2.5:1.5b

Alternativamente, bash INICIAR.sh inicia o Ollama e o site.
Ollama usa os recursos do Codespaces e pode ser lento.
As telas de conta não dependem do Ollama para funcionar.

## 5. Escolha a trilha
Entre → Trilha → Personalizar → Python ou Java → Gerar minha trilha.
Apenas a linguagem escolhida será mostrada.
A escolha fica salva na conta e é restaurada ao entrar novamente.
A estimativa usa a quantidade de aulas e as horas por semana.
O nível é registrado como preferência; não remove aulas do curso.

## Recuperação de senha
Login → Esqueci minha senha → informe o e-mail → consulte a mensagem recebida
→ digite o código e a nova senha → faça login.
Para obter outro código, use Solicitar outro código.
Para repetir a confirmação do cadastro, refaça o cadastro com o mesmo e-mail
e com a senha que deseja usar. Uma conta já confirmada não é sobrescrita.
A resposta de recuperação é genérica para não revelar quais e-mails têm conta.

## Dados e implantação
As contas, trilhas e controles de tentativas ficam em instance/accounts.sqlite3.
A chave de sessão fica em instance/session.key quando SECRET_KEY não foi definida.
Não apague instance ao atualizar. Faça backup privado da pasta.
Para outro local persistente, defina APP_DATA_DIR.
Em produção, defina SECRET_KEY com valor aleatório longo e mantenha-o estável.
Use HTTPS. No Codespaces/Render, cookies seguros são ativados automaticamente.
Para teste local em HTTP, COOKIE_SECURE=0; para hospedagem HTTPS, COOKIE_SECURE=1.
No Render, SQLite precisa de armazenamento persistente para não perder contas
ao recriar o serviço. Este ZIP não provisiona banco ou disco na hospedagem.

Progresso antigo do site sem login não é associado automaticamente às contas.
Você pode exportar um backup na versão anterior e importá-lo na conta correta.
Somente a trilha é sincronizada pelo servidor; notas e demais avanços continuam
por navegador como antes.

## Testes
    python -m unittest test_app test_tutor_ai test_local test_auth -q

Os testes usam SQLite temporário e envio simulado de e-mail; não enviam mensagens
reais. O envio real depende das suas credenciais SMTP e deve ser testado por você.

Fontes técnicas:
https://flask.palletsprojects.com/en/stable/web-security/
https://docs.python.org/3/library/smtplib.html
