import os
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

_initial = tempfile.TemporaryDirectory()
os.environ["APP_DATA_DIR"] = _initial.name
os.environ["COOKIE_SECURE"] = "0"
from app import app
from auth import SCHEMA
from werkzeug.security import generate_password_hash

class AccountTestCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        app.config.update(TESTING=True, AUTH_DATABASE=str(Path(self.tmp.name) / "test.sqlite3"), SESSION_COOKIE_SECURE=False)
        with sqlite3.connect(app.config["AUTH_DATABASE"]) as conn:
            conn.executescript(SCHEMA)
        self.client = app.test_client()
        self.mail = patch.dict(os.environ, {"SMTP_HOST":"smtp.example.test","SMTP_PORT":"587","SMTP_USER":"test","SMTP_PASSWORD":"fake","MAIL_FROM":"test@example.test"})
        self.mail.start()
        self.addCleanup(self.mail.stop)

    def csrf(self, client=None):
        client = client or self.client
        client.get("/login")
        with client.session_transaction() as session:
            return session["csrf"]

    def form(self,path,data=None,client=None):
        client = client or self.client
        payload = dict(data or {})
        payload["csrf_token"] = self.csrf(client)
        return client.post(path,data=payload)

    def authenticate(self,name="Estudante",email="test@example.test"):
        with sqlite3.connect(app.config["AUTH_DATABASE"]) as conn:
            cursor=conn.execute("INSERT INTO accounts(name,email,password_hash,verified) VALUES(?,?,?,1)",
                                (name,email,generate_password_hash("senha-teste-123")))
            uid=cursor.lastrowid
        with self.client.session_transaction() as session:
            session.update(uid=uid,version=0,csrf="testing-csrf")
        self.client.environ_base["HTTP_X_CSRF_TOKEN"]="testing-csrf"
        return uid
